pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Layouts
import LVRS 1.0 as LV
import iiAccountManager

ColumnLayout {
    id: form
    required property AccountManager manager
    readonly property bool codeRequested: Object.keys(manager.signUpChallenge).length > 0
    readonly property bool detailsReady: displayName.text.trim().length > 0 && userId.text.trim().length > 0
        && email.text.trim().length > 0 && password.text.length >= 8
        && password.text === confirmation.text && terms.checked
    property int resendWait: 0
    spacing: LV.Theme.gap12
    function clearSensitiveData() { password.text = ""; confirmation.text = ""; code.text = "" }
    function focusFirstField() { displayName.forceActiveFocus() }
    function values() {
        return {displayName: displayName.text.trim(), userId: userId.text.trim(), email: email.text.trim(),
            password: password.text, passwordConfirmation: confirmation.text,
            termsAccepted: terms.checked, emailMarketingConsent: marketing.checked}
    }
    function sendCode() {
        if (!send.enabled) return
        if (manager.requestSignUp(values())) resendWait = 60
        // Qt 6.8 tooling exposes inputMethod as QObject; hide() is a runtime slot.
        // qmllint disable missing-property
        Qt.inputMethod.hide()
        // qmllint enable missing-property
    }
    function submit() {
        if (!create.enabled) return
        manager.completeSignUp(values(), code.text)
        code.text = ""
        // Qt 6.8 tooling exposes inputMethod as QObject; hide() is a runtime slot.
        // qmllint disable missing-property
        Qt.inputMethod.hide()
        // qmllint enable missing-property
    }
    Timer { interval: 1000; repeat: true; running: form.resendWait > 0; onTriggered: --form.resendWait }
    LV.Label {
        Layout.fillWidth: true
        text: form.codeRequested ? qsTr("Enter the code sent to %1 to finish creating your account.").arg(form.manager.signUpChallenge.email)
            : qsTr("One iisacc account for your apps. Fill in your details, then verify your email.")
        wrapMode: Text.Wrap; sizeToContentHeight: true; textFormat: Text.PlainText
    }
    LV.Label { text: qsTr("Display name"); style: caption }
    LV.InputField {
        id: displayName; objectName: "signUpDisplayName"
        Layout.fillWidth: true; Layout.minimumHeight: 40
        placeholderText: qsTr("Your name"); Accessible.name: qsTr("Display name")
        maximumLength: 80; enabled: !form.manager.loading
        onAccepted: userId.forceActiveFocus()
    }
    LV.Label { text: qsTr("User ID"); style: caption }
    LV.InputField {
        id: userId; objectName: "signUpUserId"
        Layout.fillWidth: true; Layout.minimumHeight: 40
        placeholderText: qsTr("@your_id"); Accessible.name: qsTr("User ID")
        inputMethodHints: Qt.ImhNoAutoUppercase | Qt.ImhNoPredictiveText
        maximumLength: 31; enabled: !form.manager.loading
        onAccepted: email.forceActiveFocus()
    }
    LV.Label { text: qsTr("Email"); style: caption }
    LV.InputField {
        id: email; objectName: "signUpEmail"
        Layout.fillWidth: true; Layout.minimumHeight: 40
        placeholderText: qsTr("you@example.com"); Accessible.name: qsTr("Email")
        inputMethodHints: Qt.ImhEmailCharactersOnly | Qt.ImhNoAutoUppercase | Qt.ImhNoPredictiveText
        maximumLength: 254; enabled: !form.manager.loading && !form.codeRequested
        onAccepted: password.forceActiveFocus()
    }
    LV.Label { text: qsTr("Password"); style: caption }
    LV.InputField {
        id: password; objectName: "signUpPassword"
        Layout.fillWidth: true; Layout.minimumHeight: 40
        Accessible.name: qsTr("Password"); echoMode: TextInput.Password
        inputMethodHints: Qt.ImhSensitiveData | Qt.ImhNoPredictiveText | Qt.ImhNoAutoUppercase
        maximumLength: 256; enabled: !form.manager.loading
        onAccepted: confirmation.forceActiveFocus()
    }
    LV.Label { text: qsTr("Confirm password"); style: caption }
    LV.InputField {
        id: confirmation; objectName: "signUpPasswordConfirmation"
        Layout.fillWidth: true; Layout.minimumHeight: 40
        Accessible.name: qsTr("Confirm password"); echoMode: TextInput.Password
        inputMethodHints: Qt.ImhSensitiveData | Qt.ImhNoPredictiveText | Qt.ImhNoAutoUppercase
        maximumLength: 256; enabled: !form.manager.loading
        onAccepted: { if (form.codeRequested) code.forceActiveFocus() }
    }
    LV.Label {
        Layout.fillWidth: true; style: caption
        text: qsTr("Use 8–256 characters with uppercase, lowercase, a number, and a symbol. No spaces. Keep the same password until registration is complete.")
        wrapMode: Text.Wrap; sizeToContentHeight: true
    }
    RowLayout {
        Layout.fillWidth: true
        LV.CheckBox { id: terms; objectName: "signUpTerms"; enabled: !form.manager.loading; Accessible.name: qsTr("Accept Terms of Service") }
        LV.Label { text: qsTr("I agree to the Terms of Service (required)."); Layout.fillWidth: true; wrapMode: Text.Wrap; sizeToContentHeight: true }
    }
    LV.PushButton { text: qsTr("Read Terms of Service"); onClicked: Qt.openUrlExternally(form.manager.serviceUrl.toString().replace(/\/$/, "") + "/BuisnessInfo/TermsOfService") }
    RowLayout {
        Layout.fillWidth: true
        LV.CheckBox { id: marketing; objectName: "signUpMarketing"; checked: false; enabled: !form.manager.loading; Accessible.name: qsTr("Product emails, optional") }
        LV.Label { text: qsTr("Send me product emails (optional)."); Layout.fillWidth: true; wrapMode: Text.Wrap; sizeToContentHeight: true }
    }
    LV.PushButton {
        id: send; objectName: "signUpSendCode"
        Layout.fillWidth: true; Layout.minimumHeight: 40
        text: form.resendWait > 0 ? qsTr("Send again in %1s").arg(form.resendWait)
            : form.codeRequested ? qsTr("Resend code") : qsTr("Send verification code")
        enabled: !form.manager.loading && form.detailsReady && form.resendWait === 0
        onClicked: form.sendCode()
    }
    LV.InputField {
        id: code; objectName: "signUpCode"
        Layout.fillWidth: true; Layout.minimumHeight: 40; visible: form.codeRequested
        placeholderText: qsTr("Six-digit email code"); Accessible.name: qsTr("Email verification code")
        inputMethodHints: Qt.ImhDigitsOnly | Qt.ImhSensitiveData | Qt.ImhNoPredictiveText
        maximumLength: 6; validator: RegularExpressionValidator { regularExpression: /[0-9]{0,6}/ }
        enabled: !form.manager.loading; onAccepted: form.submit()
    }
    LV.PushButton {
        id: create; objectName: "signUpComplete"
        Layout.fillWidth: true; Layout.minimumHeight: 40; visible: form.codeRequested
        text: form.manager.loading ? qsTr("Creating account…") : qsTr("Create account")
        enabled: !form.manager.loading && form.detailsReady && form.codeRequested && code.text.length === 6
        onClicked: form.submit()
    }
    LV.PushButton {
        objectName: "signUpChangeEmail"; visible: form.codeRequested
        text: qsTr("Change email"); enabled: !form.manager.loading
        onClicked: { form.manager.clear(); code.text = ""; email.forceActiveFocus() }
    }
    LV.PushButton {
        objectName: "signUpSignIn"; Layout.fillWidth: true
        text: qsTr("Already have an account? Sign in"); enabled: !form.manager.loading
        onClicked: form.manager.showLogin()
    }
}
