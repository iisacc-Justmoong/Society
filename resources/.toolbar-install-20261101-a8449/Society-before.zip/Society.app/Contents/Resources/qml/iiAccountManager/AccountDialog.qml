pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as Controls
import LVRS 1.0 as LV
import iiAccountManager

LV.Sheet {
    id: panel
    objectName: "iiAccountManagerDialog"
    required property AccountManager manager
    readonly property bool signedIn: manager && manager.account.present && Object.keys(manager.loginSession).length > 0
    preferredWidth: 440
    preferredHeight: body.implicitHeight + 48
    contentPadding: 24
    showHeader: false
    scrollContent: false
    function currentForm() { return (form.item as LoginView) || (form.item as SignUpView) }
    function resetForm() { const view = currentForm(); if (view) view.clearSensitiveData() }
    function focusForm() { const view = currentForm(); if (view) view.focusFirstField() }
    function syncView() {
        if (!manager || manager.activeView === AccountManager.Closed) close()
        else open()
    }
    onClosed: {
        resetForm()
        // Qt 6.8 tooling exposes inputMethod as QObject; hide() is a runtime slot.
        // qmllint disable missing-property
        Qt.inputMethod.hide()
        // qmllint enable missing-property
        if (manager) manager.closeView()
    }
    onOpened: focusForm()
    Component.onCompleted: syncView()
    Connections {
        target: panel.manager
        function onActiveViewChanged() {
            panel.resetForm()
            panel.syncView()
        }
        function onLoaded() { if (panel.signedIn) panel.resetForm() }
    }
    Controls.ScrollView {
        id: scroll
        implicitHeight: body.implicitHeight
        anchors.fill: parent; clip: true; contentWidth: availableWidth
        ColumnLayout {
            id: body
            width: scroll.availableWidth; spacing: LV.Theme.gap16
            RowLayout {
                Layout.fillWidth: true
                LV.Label {
                    Layout.fillWidth: true; style: header
                    text: panel.signedIn ? qsTr("iisacc account")
                        : panel.manager && panel.manager.activeView === AccountManager.SignUp ? qsTr("Create an account") : qsTr("Sign in")
                }
                LV.PushButton { objectName: "accountClose"; text: qsTr("Close"); onClicked: panel.manager.closeView() }
            }
            Loader {
                id: form
                Layout.fillWidth: true
                active: panel.visible && !panel.signedIn && panel.manager !== null && !panel.manager.restoringSession
                sourceComponent: panel.manager && panel.manager.activeView === AccountManager.SignUp ? signUpComponent : loginComponent
                onLoaded: { if (panel.visible) panel.focusForm() }
            }
            Component { id: loginComponent; LoginView { manager: panel.manager } }
            Component { id: signUpComponent; SignUpView { manager: panel.manager } }
            LV.Label {
                objectName: "accountRestoringSession"; Layout.fillWidth: true
                visible: panel.manager && panel.manager.restoringSession
                text: qsTr("Restoring your sign-in…")
                wrapMode: Text.Wrap; sizeToContentHeight: true
            }
            ColumnLayout {
                visible: panel.signedIn; Layout.fillWidth: true; spacing: LV.Theme.gap12
                LV.Label {
                    objectName: "accountDisplayName"; Layout.fillWidth: true; style: title2
                    text: panel.manager ? panel.manager.account.displayLabel : ""
                    textFormat: Text.PlainText; wrapMode: Text.Wrap; sizeToContentHeight: true
                }
                LV.Label { Layout.fillWidth: true; text: panel.manager ? panel.manager.account.email : ""; textFormat: Text.PlainText; wrapMode: Text.Wrap; sizeToContentHeight: true }
                LV.Label { Layout.fillWidth: true; text: panel.manager ? panel.manager.account.userId : ""; textFormat: Text.PlainText; visible: text.length > 0 }
                LV.Label { text: panel.manager ? qsTr("Society Cloud · %1").arg(panel.manager.account.toVariantMap().societyCloudMembership) : ""; textFormat: Text.PlainText }
                LV.PushButton { Layout.fillWidth: true; text: qsTr("Manage account"); onClicked: Qt.openUrlExternally(panel.manager.serviceUrl.toString().replace(/\/$/, "") + "/Account") }
                LV.PushButton { objectName: "accountRefresh"; Layout.fillWidth: true; text: qsTr("Refresh account"); enabled: panel.manager && !panel.manager.loading; onClicked: panel.manager.refresh() }
                LV.PushButton { objectName: "accountSignOut"; Layout.fillWidth: true; text: qsTr("Sign out"); enabled: panel.manager && !panel.manager.loading; onClicked: panel.manager.logout() }
            }
            LV.Label {
                objectName: "accountError"; Layout.fillWidth: true
                text: panel.manager ? panel.manager.errorString : ""; visible: text.length > 0
                textFormat: Text.PlainText; wrapMode: Text.Wrap; sizeToContentHeight: true
            }
            LV.Label {
                objectName: "accountStorageError"; Layout.fillWidth: true
                text: panel.manager ? panel.manager.sessionStorageError : ""; visible: text.length > 0
                textFormat: Text.PlainText; wrapMode: Text.Wrap; sizeToContentHeight: true
            }
        }
    }
}
