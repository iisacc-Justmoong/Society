pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Layouts
import LVRS 1.0 as LV
import iiAccountManager

ColumnLayout {
    id: form
    required property AccountManager manager
    spacing: LV.Theme.gap12
    function clearSensitiveData() { password.text = "" }
    function focusFirstField() { email.forceActiveFocus() }
    function submit() {
        if (!signIn.enabled) return
        manager.loginWithPassword(email.text.trim(), password.text)
        password.text = ""
        // Qt 6.8 tooling exposes inputMethod as QObject; hide() is a runtime slot.
        // qmllint disable missing-property
        Qt.inputMethod.hide()
        // qmllint enable missing-property
    }
    LV.Label { Layout.fillWidth: true; text: qsTr("Sign in with your iisacc.com account."); wrapMode: Text.Wrap; sizeToContentHeight: true }
    LV.Label { text: qsTr("Email"); style: caption }
    LV.InputField {
        id: email
        objectName: "accountEmail"
        Layout.fillWidth: true
        Layout.minimumHeight: 40
        placeholderText: qsTr("you@example.com")
        Accessible.name: qsTr("Email")
        inputMethodHints: Qt.ImhEmailCharactersOnly | Qt.ImhNoAutoUppercase | Qt.ImhNoPredictiveText
        maximumLength: 254
        enabled: !form.manager.loading
        onAccepted: password.forceActiveFocus()
    }
    LV.Label { text: qsTr("Password"); style: caption }
    LV.InputField {
        id: password
        objectName: "accountPassword"
        Layout.fillWidth: true
        Layout.minimumHeight: 40
        placeholderText: qsTr("Password")
        Accessible.name: qsTr("Password")
        echoMode: TextInput.Password
        inputMethodHints: Qt.ImhSensitiveData | Qt.ImhNoPredictiveText | Qt.ImhNoAutoUppercase
        maximumLength: 256
        enabled: !form.manager.loading
        onAccepted: form.submit()
    }
    LV.PushButton {
        id: signIn
        objectName: "accountSignIn"
        Layout.fillWidth: true
        Layout.minimumHeight: 40
        text: form.manager.loading ? qsTr("Signing in…") : qsTr("Sign in")
        enabled: !form.manager.loading && email.text.trim().length > 0 && password.text.length > 0
        onClicked: form.submit()
    }
    LV.PushButton {
        objectName: "accountCreate"
        Layout.fillWidth: true
        text: qsTr("Create an iisacc account")
        enabled: !form.manager.loading
        onClicked: form.manager.showSignUp()
    }
}
