pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls as Controls
import QtQuick.Layouts
import LVRS 1.0 as LV
import Society

LV.ContextMenu {
    id: menu
    property string filePath: ""
    property string folderPath: ""
    property bool directory: false
    property bool backgroundOnly: false
    property var categoryOptions: []
    property bool categoryEnabled: true
    property string currentCategory: ""
    readonly property alias categoryMenu: categoryMenu
    readonly property alias actions: actions
    signal openRequested(string path)
    signal revealRequested(string path)
    signal modified(string path)
    signal categoryRequested(string path, string category)
    showIconSlot: false
    itemWidth: 220
    property FileActions handler: FileActions {
        id: actions
        path: menu.filePath
        onCompleted: function(path) { menu.modified(path) }
    }
    items: backgroundOnly ? [{ label: qsTr("Paste"), enabled: actions.canPaste && !actions.busy }] : [
        { label: qsTr("Open"), enabled: !actions.busy },
        { label: qsTr("Show in folder"), enabled: !actions.busy },
        { label: qsTr("Copy"), enabled: actions.editable && !actions.busy },
        { label: qsTr("Copy path"), enabled: filePath.length > 0 },
        { label: qsTr("Paste"), enabled: actions.canPaste && !actions.busy },
        { label: qsTr("Duplicate"), enabled: actions.editable && !actions.busy },
        { label: qsTr("Rename…"), enabled: actions.editable && !actions.busy },
        { label: qsTr("Share…"), enabled: actions.canShare && actions.editable && !actions.busy },
        { label: actions.inDeleted ? qsTr("Remove from Deleted…") : qsTr("Delete"), enabled: actions.editable && !actions.busy }
    ].concat(categoryOptions.length ? [{ label: qsTr("Categories"), enabled: categoryEnabled && !actions.busy,
        hasChildItems: true, showChevron: true, keepOpen: true }] : [])
    onItemTriggered: function(index) {
        if (backgroundOnly) { actions.paste(folderPath); return }
        switch (index) {
        case 0: openRequested(filePath); break
        case 1: revealRequested(folderPath); break
        case 2: actions.copy(); break
        case 3: actions.copyPath(); break
        case 4: actions.paste(directory ? filePath : folderPath); break
        case 5: actions.duplicate(); break
        case 6:
            renameSheet.selectedPath = filePath
            nameInput.text = filePath.substring(filePath.lastIndexOf("/") + 1)
            renameSheet.open()
            nameInput.forceActiveFocus()
            break
        case 7: actions.share(); break
        case 8:
            if (actions.inDeleted) { deleteSheet.selectedPath = filePath; deleteSheet.open() }
            else actions.trash()
            break
        case 9:
            categoryMenu.openAt(menu.x + menu.width, menu.y)
            break
        }
    }
    onClosed: categoryMenu.close()
    property LV.ContextMenu categoryPopup: LV.ContextMenu {
        id: categoryMenu
        objectName: "modelCategoryMenu"
        showIconSlot: false
        itemWidth: 220
        items: menu.categoryOptions.map(function(option) {
            return { label: option.title, category: option.key, selected: option.key === menu.currentCategory }
        })
        implicitHeight: categoryList.implicitHeight + topPadding + bottomPadding
        contentItem: ListView {
            id: categoryList
            objectName: "modelCategoryList"
            clip: true
            implicitWidth: categoryMenu.resolvedItemWidth
            implicitHeight: Math.min(contentHeight, Math.max(0, (categoryMenu.parent ? categoryMenu.parent.height : 600)
                - categoryMenu.topPadding - categoryMenu.bottomPadding - categoryMenu.edgeMargin * 2))
            spacing: categoryMenu.itemSpacing
            model: categoryMenu.entryDelegateItems
            boundsBehavior: Flickable.StopAtBounds
            Controls.ScrollBar.vertical: Controls.ScrollBar { policy: Controls.ScrollBar.AsNeeded }
            delegate: LV.ContextMenuItem {
                required property var modelData
                objectName: "modelCategoryOption" + modelData.index
                width: categoryList.width
                label: modelData.label || ""
                state: modelData.state === undefined ? defaultState : modelData.state
                showIconSlot: false
                enabled: modelData.enabled !== false
                onClicked: categoryMenu.triggerEntry(modelData.index)
            }
        }
        onItemTriggered: function(index, entry) {
            menu.categoryRequested(menu.filePath, entry.category)
            menu.close()
        }
    }
    property LV.Sheet renameDialog: LV.Sheet {
        id: renameSheet
        objectName: "renameFileSheet"
        property string selectedPath: ""
        title: qsTr("Rename")
        preferredHeight: 230
        LV.VStack {
            width: parent.width
            spacing: 16
            LV.InputField { id: nameInput; objectName: "fileNameInput"; Layout.fillWidth: true; placeholderText: qsTr("File name") }
            LV.HStack {
                Layout.fillWidth: true
                Item { Layout.fillWidth: true }
                LV.LabelButton { text: qsTr("Cancel"); onClicked: renameSheet.close() }
                LV.LabelButton {
                    objectName: "confirmFileRename"
                    text: qsTr("Rename")
                    enabled: nameInput.text.trim().length > 0 && !actions.busy
                    onClicked: { actions.rename(nameInput.text); renameSheet.close() }
                }
            }
        }
    }
    property LV.Sheet deleteDialog: LV.Sheet {
        id: deleteSheet
        objectName: "deleteFileSheet"
        property string selectedPath: ""
        title: qsTr("Remove from Deleted?")
        preferredHeight: 260
        LV.VStack {
            width: parent.width
            spacing: 16
            LV.Label {
                Layout.fillWidth: true
                text: qsTr("“%1” will be removed from Deleted. Any managed originals and recorded history are retained.").arg(deleteSheet.selectedPath.substring(deleteSheet.selectedPath.lastIndexOf("/") + 1))
                textFormat: Text.PlainText
                wrapMode: Text.Wrap
                sizeToContentHeight: true
            }
            LV.HStack {
                Layout.fillWidth: true
                Item { Layout.fillWidth: true }
                LV.LabelButton { text: qsTr("Cancel"); onClicked: deleteSheet.close() }
                LV.LabelButton {
                    objectName: "confirmPermanentDelete"
                    text: qsTr("Remove from Deleted")
                    enabled: !actions.busy
                    onClicked: { actions.remove(); deleteSheet.close() }
                }
            }
        }
    }
}
