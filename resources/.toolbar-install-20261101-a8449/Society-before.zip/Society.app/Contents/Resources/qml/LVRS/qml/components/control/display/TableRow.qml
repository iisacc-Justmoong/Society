pragma ComponentBehavior: Bound
import QtQuick
import LVRS 1.0

Item {
    id: control

    property var cellItems: undefined
    property var cells: ["Text", "Text", "Text"] // legacy fallback
    property int cellWidth: Theme.scaleMetric(234)
    property int cellHeight: Theme.scaleMetric(24)
    property int contentSpacing: Theme.gap8
    property color dividerColor: Theme.panelBackground10
    property color textColor: Theme.bodyColor
    property bool inputable: false

    signal cellInputEdited(int columnIndex, string text)
    signal cellInputSubmitted(int columnIndex, string text)

    readonly property var resolvedCellSource: {
        if (control.cellItems !== undefined && control.cellItems !== null)
            return control.cellItems
        return control.cells
    }
    readonly property int resolvedCellCount: {
        const source = control.resolvedCellSource
        if (!source)
            return 0
        if (source.length !== undefined)
            return source.length
        if (source.count !== undefined)
            return source.count
        return 0
    }

    readonly property real resolvedSpacing: {
        const count = Math.max(1, resolvedCellCount)
        if (count <= 1)
            return 0
        const computed = (width - (count * cellWidth)) / (count - 1)
        return Math.max(0, computed)
    }

    function cellAt(index) {
        const source = control.resolvedCellSource
        if (!source)
            return null
        if (source.length !== undefined)
            return source[index]
        if (source.get !== undefined)
            return source.get(index)
        return null
    }

    function cellText(index) {
        if (resolvedCellCount <= 0)
            return "Text"

        const entry = cellAt(index)
        if (typeof entry === "string" || typeof entry === "number")
            return String(entry)
        if (!entry || typeof entry !== "object")
            return "Text"
        return entry.label || entry.text || entry.title || "Text"
    }

    function cellInputable(index) {
        const entry = cellAt(index)
        if (entry && typeof entry === "object" && Object.prototype.hasOwnProperty.call(entry, "inputable"))
            return !!entry.inputable
        return control.inputable
    }

    implicitWidth: Theme.scaleMetric(717)
    implicitHeight: cellHeight

    Row {
        anchors.fill: parent
        spacing: control.resolvedSpacing

        Repeater {
            model: Math.max(1, control.resolvedCellCount)

            delegate: TableCellItem {
                required property int index

                objectName: control.objectName.length > 0
                    ? control.objectName + "_cell_" + index
                    : ""
                width: control.cellWidth
                height: control.cellHeight
                itemData: control.cellAt(index)
                text: control.cellText(index)
                contentSpacing: control.contentSpacing
                dividerColor: control.dividerColor
                textColor: control.textColor
                clipContent: true
                inputable: control.cellInputable(index)
                onInputEdited: function(text) {
                    control.cellInputEdited(index, text)
                }
                onInputSubmitted: function(text) {
                    control.cellInputSubmitted(index, text)
                }
            }
        }
    }
}

// API usage (external):
// import LVRS 1.0 as LV
// LV.TableRow { cellItems: [{ text: "Text" }, { text: "Text" }, { text: "Text" }]; inputable: true }
